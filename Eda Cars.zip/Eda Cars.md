```python
import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt
%matplotlib inline
sns.set(color_codes=True)
```


```python
df = pd.read_csv('C:/Users/Rakesh/Datasets/data.csv')
```


```python
df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Make</th>
      <th>Model</th>
      <th>Year</th>
      <th>Engine Fuel Type</th>
      <th>Engine HP</th>
      <th>Engine Cylinders</th>
      <th>Transmission Type</th>
      <th>Driven_Wheels</th>
      <th>Number of Doors</th>
      <th>Market Category</th>
      <th>Vehicle Size</th>
      <th>Vehicle Style</th>
      <th>highway MPG</th>
      <th>city mpg</th>
      <th>Popularity</th>
      <th>MSRP</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>BMW</td>
      <td>1 Series M</td>
      <td>2011</td>
      <td>premium unleaded (required)</td>
      <td>335.0</td>
      <td>6.0</td>
      <td>MANUAL</td>
      <td>rear wheel drive</td>
      <td>2.0</td>
      <td>Factory Tuner,Luxury,High-Performance</td>
      <td>Compact</td>
      <td>Coupe</td>
      <td>26</td>
      <td>19</td>
      <td>3916</td>
      <td>46135</td>
    </tr>
    <tr>
      <th>1</th>
      <td>BMW</td>
      <td>1 Series</td>
      <td>2011</td>
      <td>premium unleaded (required)</td>
      <td>300.0</td>
      <td>6.0</td>
      <td>MANUAL</td>
      <td>rear wheel drive</td>
      <td>2.0</td>
      <td>Luxury,Performance</td>
      <td>Compact</td>
      <td>Convertible</td>
      <td>28</td>
      <td>19</td>
      <td>3916</td>
      <td>40650</td>
    </tr>
    <tr>
      <th>2</th>
      <td>BMW</td>
      <td>1 Series</td>
      <td>2011</td>
      <td>premium unleaded (required)</td>
      <td>300.0</td>
      <td>6.0</td>
      <td>MANUAL</td>
      <td>rear wheel drive</td>
      <td>2.0</td>
      <td>Luxury,High-Performance</td>
      <td>Compact</td>
      <td>Coupe</td>
      <td>28</td>
      <td>20</td>
      <td>3916</td>
      <td>36350</td>
    </tr>
    <tr>
      <th>3</th>
      <td>BMW</td>
      <td>1 Series</td>
      <td>2011</td>
      <td>premium unleaded (required)</td>
      <td>230.0</td>
      <td>6.0</td>
      <td>MANUAL</td>
      <td>rear wheel drive</td>
      <td>2.0</td>
      <td>Luxury,Performance</td>
      <td>Compact</td>
      <td>Coupe</td>
      <td>28</td>
      <td>18</td>
      <td>3916</td>
      <td>29450</td>
    </tr>
    <tr>
      <th>4</th>
      <td>BMW</td>
      <td>1 Series</td>
      <td>2011</td>
      <td>premium unleaded (required)</td>
      <td>230.0</td>
      <td>6.0</td>
      <td>MANUAL</td>
      <td>rear wheel drive</td>
      <td>2.0</td>
      <td>Luxury</td>
      <td>Compact</td>
      <td>Convertible</td>
      <td>28</td>
      <td>18</td>
      <td>3916</td>
      <td>34500</td>
    </tr>
  </tbody>
</table>
</div>




```python
df.dtypes
```




    Make                  object
    Model                 object
    Year                   int64
    Engine Fuel Type      object
    Engine HP            float64
    Engine Cylinders     float64
    Transmission Type     object
    Driven_Wheels         object
    Number of Doors      float64
    Market Category       object
    Vehicle Size          object
    Vehicle Style         object
    highway MPG            int64
    city mpg               int64
    Popularity             int64
    MSRP                   int64
    dtype: object




```python
df['Engine Fuel Type'].unique()
```




    array(['premium unleaded (required)', 'regular unleaded',
           'premium unleaded (recommended)', 'flex-fuel (unleaded/E85)',
           'diesel', 'electric',
           'flex-fuel (premium unleaded recommended/E85)', 'natural gas',
           'flex-fuel (premium unleaded required/E85)',
           'flex-fuel (unleaded/natural gas)', nan], dtype=object)




```python
df['Market Category'].value_counts()
```




    Crossover                                          1110
    Flex Fuel                                           872
    Luxury                                              855
    Luxury,Performance                                  673
    Hatchback                                           641
                                                       ... 
    Crossover,Exotic,Luxury,Performance                   1
    Exotic,Luxury,High-Performance,Hybrid                 1
    Crossover,Exotic,Luxury,High-Performance              1
    Flex Fuel,Factory Tuner,Luxury,High-Performance       1
    Performance,Hybrid                                    1
    Name: Market Category, Length: 71, dtype: int64




```python
df=df.drop(['Engine Fuel Type','Market Category', 'Vehicle Style', 'Popularity', 'Number of Doors', 'Vehicle Size'], axis=1)
```


```python
df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Make</th>
      <th>Model</th>
      <th>Year</th>
      <th>Engine HP</th>
      <th>Engine Cylinders</th>
      <th>Transmission Type</th>
      <th>Driven_Wheels</th>
      <th>highway MPG</th>
      <th>city mpg</th>
      <th>MSRP</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>BMW</td>
      <td>1 Series M</td>
      <td>2011</td>
      <td>335.0</td>
      <td>6.0</td>
      <td>MANUAL</td>
      <td>rear wheel drive</td>
      <td>26</td>
      <td>19</td>
      <td>46135</td>
    </tr>
    <tr>
      <th>1</th>
      <td>BMW</td>
      <td>1 Series</td>
      <td>2011</td>
      <td>300.0</td>
      <td>6.0</td>
      <td>MANUAL</td>
      <td>rear wheel drive</td>
      <td>28</td>
      <td>19</td>
      <td>40650</td>
    </tr>
    <tr>
      <th>2</th>
      <td>BMW</td>
      <td>1 Series</td>
      <td>2011</td>
      <td>300.0</td>
      <td>6.0</td>
      <td>MANUAL</td>
      <td>rear wheel drive</td>
      <td>28</td>
      <td>20</td>
      <td>36350</td>
    </tr>
    <tr>
      <th>3</th>
      <td>BMW</td>
      <td>1 Series</td>
      <td>2011</td>
      <td>230.0</td>
      <td>6.0</td>
      <td>MANUAL</td>
      <td>rear wheel drive</td>
      <td>28</td>
      <td>18</td>
      <td>29450</td>
    </tr>
    <tr>
      <th>4</th>
      <td>BMW</td>
      <td>1 Series</td>
      <td>2011</td>
      <td>230.0</td>
      <td>6.0</td>
      <td>MANUAL</td>
      <td>rear wheel drive</td>
      <td>28</td>
      <td>18</td>
      <td>34500</td>
    </tr>
  </tbody>
</table>
</div>




```python
df=df.rename(columns={'Engine HP':'HP','Engine Cylinders':'Cylinders','Transmission Type':'Transmission','Driven_Wheels':'Drive Mode', 'highway MPG':'MPG-H', 'city mpg':'MPG-C', 'MSRP': "Price" })
```


```python
df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Make</th>
      <th>Model</th>
      <th>Year</th>
      <th>HP</th>
      <th>Cylinders</th>
      <th>Transmission</th>
      <th>Drive Mode</th>
      <th>MPG-H</th>
      <th>MPG-C</th>
      <th>Price</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>BMW</td>
      <td>1 Series M</td>
      <td>2011</td>
      <td>335.0</td>
      <td>6.0</td>
      <td>MANUAL</td>
      <td>rear wheel drive</td>
      <td>26</td>
      <td>19</td>
      <td>46135</td>
    </tr>
    <tr>
      <th>1</th>
      <td>BMW</td>
      <td>1 Series</td>
      <td>2011</td>
      <td>300.0</td>
      <td>6.0</td>
      <td>MANUAL</td>
      <td>rear wheel drive</td>
      <td>28</td>
      <td>19</td>
      <td>40650</td>
    </tr>
    <tr>
      <th>2</th>
      <td>BMW</td>
      <td>1 Series</td>
      <td>2011</td>
      <td>300.0</td>
      <td>6.0</td>
      <td>MANUAL</td>
      <td>rear wheel drive</td>
      <td>28</td>
      <td>20</td>
      <td>36350</td>
    </tr>
    <tr>
      <th>3</th>
      <td>BMW</td>
      <td>1 Series</td>
      <td>2011</td>
      <td>230.0</td>
      <td>6.0</td>
      <td>MANUAL</td>
      <td>rear wheel drive</td>
      <td>28</td>
      <td>18</td>
      <td>29450</td>
    </tr>
    <tr>
      <th>4</th>
      <td>BMW</td>
      <td>1 Series</td>
      <td>2011</td>
      <td>230.0</td>
      <td>6.0</td>
      <td>MANUAL</td>
      <td>rear wheel drive</td>
      <td>28</td>
      <td>18</td>
      <td>34500</td>
    </tr>
  </tbody>
</table>
</div>



# Dropping the duplicate rows


```python
duplicate_df=df[df.duplicated()]
```


```python
duplicate_df.shape
```




    (989, 10)




```python
df.count()
```




    Make            11914
    Model           11914
    Year            11914
    HP              11845
    Cylinders       11884
    Transmission    11914
    Drive Mode      11914
    MPG-H           11914
    MPG-C           11914
    Price           11914
    dtype: int64




```python
df.isnull().sum()
```




    Make             0
    Model            0
    Year             0
    HP              69
    Cylinders       30
    Transmission     0
    Drive Mode       0
    MPG-H            0
    MPG-C            0
    Price            0
    dtype: int64




```python
df.shape
```




    (11914, 10)




```python
df=df.drop_duplicates()
```


```python
df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Make</th>
      <th>Model</th>
      <th>Year</th>
      <th>HP</th>
      <th>Cylinders</th>
      <th>Transmission</th>
      <th>Drive Mode</th>
      <th>MPG-H</th>
      <th>MPG-C</th>
      <th>Price</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>BMW</td>
      <td>1 Series M</td>
      <td>2011</td>
      <td>335.0</td>
      <td>6.0</td>
      <td>MANUAL</td>
      <td>rear wheel drive</td>
      <td>26</td>
      <td>19</td>
      <td>46135</td>
    </tr>
    <tr>
      <th>1</th>
      <td>BMW</td>
      <td>1 Series</td>
      <td>2011</td>
      <td>300.0</td>
      <td>6.0</td>
      <td>MANUAL</td>
      <td>rear wheel drive</td>
      <td>28</td>
      <td>19</td>
      <td>40650</td>
    </tr>
    <tr>
      <th>2</th>
      <td>BMW</td>
      <td>1 Series</td>
      <td>2011</td>
      <td>300.0</td>
      <td>6.0</td>
      <td>MANUAL</td>
      <td>rear wheel drive</td>
      <td>28</td>
      <td>20</td>
      <td>36350</td>
    </tr>
    <tr>
      <th>3</th>
      <td>BMW</td>
      <td>1 Series</td>
      <td>2011</td>
      <td>230.0</td>
      <td>6.0</td>
      <td>MANUAL</td>
      <td>rear wheel drive</td>
      <td>28</td>
      <td>18</td>
      <td>29450</td>
    </tr>
    <tr>
      <th>4</th>
      <td>BMW</td>
      <td>1 Series</td>
      <td>2011</td>
      <td>230.0</td>
      <td>6.0</td>
      <td>MANUAL</td>
      <td>rear wheel drive</td>
      <td>28</td>
      <td>18</td>
      <td>34500</td>
    </tr>
  </tbody>
</table>
</div>




```python
df.count()
```




    Make            10925
    Model           10925
    Year            10925
    HP              10856
    Cylinders       10895
    Transmission    10925
    Drive Mode      10925
    MPG-H           10925
    MPG-C           10925
    Price           10925
    dtype: int64




```python
df=df.dropna()
```


```python
df.count()
```




    Make            10827
    Model           10827
    Year            10827
    HP              10827
    Cylinders       10827
    Transmission    10827
    Drive Mode      10827
    MPG-H           10827
    MPG-C           10827
    Price           10827
    dtype: int64




```python
df.describe()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Year</th>
      <th>HP</th>
      <th>Cylinders</th>
      <th>MPG-H</th>
      <th>MPG-C</th>
      <th>Price</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>10827.000000</td>
      <td>10827.000000</td>
      <td>10827.000000</td>
      <td>10827.000000</td>
      <td>10827.000000</td>
      <td>1.082700e+04</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>2010.896370</td>
      <td>254.553062</td>
      <td>5.691604</td>
      <td>26.308119</td>
      <td>19.327607</td>
      <td>4.249325e+04</td>
    </tr>
    <tr>
      <th>std</th>
      <td>7.029534</td>
      <td>109.841537</td>
      <td>1.768551</td>
      <td>7.504652</td>
      <td>6.643567</td>
      <td>6.229451e+04</td>
    </tr>
    <tr>
      <th>min</th>
      <td>1990.000000</td>
      <td>55.000000</td>
      <td>0.000000</td>
      <td>12.000000</td>
      <td>7.000000</td>
      <td>2.000000e+03</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>2007.000000</td>
      <td>173.000000</td>
      <td>4.000000</td>
      <td>22.000000</td>
      <td>16.000000</td>
      <td>2.197250e+04</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>2015.000000</td>
      <td>240.000000</td>
      <td>6.000000</td>
      <td>25.000000</td>
      <td>18.000000</td>
      <td>3.084500e+04</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>2016.000000</td>
      <td>303.000000</td>
      <td>6.000000</td>
      <td>30.000000</td>
      <td>22.000000</td>
      <td>4.330000e+04</td>
    </tr>
    <tr>
      <th>max</th>
      <td>2017.000000</td>
      <td>1001.000000</td>
      <td>16.000000</td>
      <td>354.000000</td>
      <td>137.000000</td>
      <td>2.065902e+06</td>
    </tr>
  </tbody>
</table>
</div>




```python
sns.boxplot(x=df['Price'])
```




    <AxesSubplot:xlabel='Price'>




    
![png](output_22_1.png)
    



```python
sns.boxplot(x=df['HP'])
```




    <AxesSubplot:xlabel='HP'>




    
![png](output_23_1.png)
    



```python
sns.boxplot(x=df['Cylinders'])
```




    <AxesSubplot:xlabel='Cylinders'>




    
![png](output_24_1.png)
    



```python
Q1 = df.quantile(0.25)
Q3 = df.quantile(0.75)
IQR = Q3-Q1
print(IQR)
```

    Year             9.0
    HP             130.0
    Cylinders        2.0
    MPG-H            8.0
    MPG-C            6.0
    Price        21327.5
    dtype: float64
    


```python
df = df[~((df < (Q1 - 1.5* IQR)) | (df >(Q3 + 1.5 * IQR))).any(axis=1)]
df.shape
```

    C:\Users\Rakesh\AppData\Local\Temp\ipykernel_9032\626683254.py:1: FutureWarning: Automatic reindexing on DataFrame vs Series comparisons is deprecated and will raise ValueError in a future version. Do `left, right = left.align(right, axis=1, copy=False)` before e.g. `left == right`
      df = df[~((df < (Q1 - 1.5* IQR)) | (df >(Q3 + 1.5 * IQR))).any(axis=1)]
    




    (9191, 10)




```python
df.Make.value_counts().nlargest(40).plot(kind='bar', figsize=(10,5))
plt.title('Number of cars by make')
plt.ylabel('Number of cars')
plt.xlabel('Make');
```


    
![png](output_27_0.png)
    



```python
plt.figure(figsize=(10,15))
c=df.corr()
sns.heatmap(c,cmap='BrBG', annot=True)
c
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Year</th>
      <th>HP</th>
      <th>Cylinders</th>
      <th>MPG-H</th>
      <th>MPG-C</th>
      <th>Price</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Year</th>
      <td>1.000000</td>
      <td>0.326726</td>
      <td>-0.133920</td>
      <td>0.378479</td>
      <td>0.338145</td>
      <td>0.592983</td>
    </tr>
    <tr>
      <th>HP</th>
      <td>0.326726</td>
      <td>1.000000</td>
      <td>0.715237</td>
      <td>-0.443807</td>
      <td>-0.544551</td>
      <td>0.739042</td>
    </tr>
    <tr>
      <th>Cylinders</th>
      <td>-0.133920</td>
      <td>0.715237</td>
      <td>1.000000</td>
      <td>-0.703856</td>
      <td>-0.755540</td>
      <td>0.354013</td>
    </tr>
    <tr>
      <th>MPG-H</th>
      <td>0.378479</td>
      <td>-0.443807</td>
      <td>-0.703856</td>
      <td>1.000000</td>
      <td>0.939141</td>
      <td>-0.106320</td>
    </tr>
    <tr>
      <th>MPG-C</th>
      <td>0.338145</td>
      <td>-0.544551</td>
      <td>-0.755540</td>
      <td>0.939141</td>
      <td>1.000000</td>
      <td>-0.180515</td>
    </tr>
    <tr>
      <th>Price</th>
      <td>0.592983</td>
      <td>0.739042</td>
      <td>0.354013</td>
      <td>-0.106320</td>
      <td>-0.180515</td>
      <td>1.000000</td>
    </tr>
  </tbody>
</table>
</div>




    
![png](output_28_1.png)
    



```python
fig, ax=plt.subplots(figsize=(10,6))
ax.scatter(df['HP'], df['Price'])
ax.set_xlabel('HP')
ax.set_ylabel('Price')
plt.show()
```


    
![png](output_29_0.png)
    

